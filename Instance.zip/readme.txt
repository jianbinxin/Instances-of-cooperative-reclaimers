Lines 1–12: Data Required by the Time-Space Network (TSN) Model
Line 1: All nodes (including stockpile nodes and home nodes)
Line 2: All stockpile nodes
Line 3: All tracks
Line 4: Planning time horizon
Line 5: All reclaimers
Line 6: Home positions of all reclaimers
Line 7: Compatibility pairs between reclaimers (first) and stockpiles (second), where “1” indicates that the reclaimer can serve the stockpile, and “0” indicates it cannot
Line 8: Required reclaiming time (length) for each stockpile
Line 9: All overlapping stockpiles on both sides of each track
Line 10: All fully overlapping stockpiles on both sides of each track
Line 11: Positional relationships among reclaimers on each track (the first is on the left side of the second)
Line 12: Positional relationships among stockpiles on both sides of each track (the first is on the left side of the second)

Lines 13–25: Data Required by the Algorithm
Line 13: Number of stockpiles
Line 14: Number of tracks
Line 15: All stockpile nodes
Line 16: Home positions of all reclaimers
Line 17: Required reclaiming time (length) for each stockpile
Line 18: Compatibility relationships between reclaimers and stockpiles
Line 19: Reclaimers sharing the same track as each reclaimer
Line 20: Reclaimers on each track
Line 21: Positional relationships among nodes, specifying which nodes lie to the left of each node
Line 22: All overlapping stockpiles for each stockpile
Line 23: All fully overlapping stockpiles for each stockpile
Line 24: Planning time horizon
Line 25: All stockpiles on each pad